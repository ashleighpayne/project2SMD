import java.util.ArrayList;
import java.util.List;

public class PurchaseListModel {
    public List<PurchaseModel> purchases = new ArrayList<>();
}
