import java.util.ArrayList;
import java.util.List;

    public class ProductListModel {
        public List<ProductModel> products = new ArrayList<>();
    }
